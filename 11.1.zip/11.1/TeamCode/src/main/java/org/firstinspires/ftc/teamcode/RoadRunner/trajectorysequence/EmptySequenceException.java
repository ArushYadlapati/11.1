package org.firstinspires.ftc.teamcode.RoadRunner.trajectorysequence;


public class EmptySequenceException extends RuntimeException { }
